export const environment = {
  production: true,
  apiUrl: 'https://mooganic.com/api/admin/'
};
