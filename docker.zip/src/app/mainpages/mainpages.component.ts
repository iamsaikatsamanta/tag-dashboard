import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mainpages',
  templateUrl: './mainpages.component.html',
  styleUrls: ['./mainpages.component.css']
})
export class MainpagesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
