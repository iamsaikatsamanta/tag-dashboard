export interface filemodel {
    result:any  ,
    code:any

}
