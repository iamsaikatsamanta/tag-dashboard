
export interface campaignmodel {
    campaign:any,
    follower:any,
    _id:any,
    name:any,
    category:any,
    coverphoto:any,
    logo:any,
    description:any,
    facebook_link:any,
    result:any
}