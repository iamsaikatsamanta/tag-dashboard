export interface categorymodel {
    result:any,
    id: any,
    name: any,
    imgUrl:any

}
