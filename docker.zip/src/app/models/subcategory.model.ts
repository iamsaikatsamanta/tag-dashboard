export interface subcategorymodel {
    result:any,
    id: any,
    name: any,
    mainCatagoty:any


}
