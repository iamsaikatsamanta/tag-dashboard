export interface RESTAPI {
  code: number;
  result: any;
  messege: any;
  status: any;
}
