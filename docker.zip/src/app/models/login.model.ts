export interface loginmodel {
    
    result:any
}